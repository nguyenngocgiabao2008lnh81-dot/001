export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { text, openaiKey, elevenKey } = req.body;
  if (!text || !openaiKey) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    // Call OpenAI Chat API
    const completion = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Bạn là Ivy, thư ký AI người Việt, nhưng thuần thục tiếng Anh." },
          { role: "user", content: text }
        ]
      })
    });

    const completionData = await completion.json();
    const reply = completionData.choices?.[0]?.message?.content || "Xin lỗi, tôi không có câu trả lời.";

    let audioBase64 = null;
    if (elevenKey) {
      const voiceId = "21m00Tcm4TlvDq8ikWAM"; // giọng mặc định của ElevenLabs
      const ttsResponse = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: "POST",
        headers: {
          "Accept": "audio/mpeg",
          "Content-Type": "application/json",
          "xi-api-key": elevenKey,
        },
        body: JSON.stringify({
          text: reply,
          model_id: "eleven_monolingual_v1",
          voice_settings: { stability: 0.5, similarity_boost: 0.75 }
        })
      });

      if (ttsResponse.ok) {
        const buffer = Buffer.from(await ttsResponse.arrayBuffer());
        audioBase64 = buffer.toString("base64");
      }
    }

    return res.status(200).json({ reply, audio: audioBase64 });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
